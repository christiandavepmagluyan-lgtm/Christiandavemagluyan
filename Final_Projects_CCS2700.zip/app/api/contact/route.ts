import { NextResponse } from "next/server"

interface ContactFormData {
  name: string
  email: string
  subject: string
  message: string
}

// Simple validation
function validateFormData(data: ContactFormData): string | null {
  if (!data.name || data.name.trim().length < 2) {
    return "Name must be at least 2 characters"
  }
  if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    return "Please provide a valid email address"
  }
  if (!data.subject || data.subject.trim().length < 3) {
    return "Subject must be at least 3 characters"
  }
  if (!data.message || data.message.trim().length < 10) {
    return "Message must be at least 10 characters"
  }
  return null
}

// Rate limiting (simple in-memory for demo - use Redis/KV in production)
const rateLimit = new Map<string, { count: number; timestamp: number }>()
const RATE_LIMIT_WINDOW = 60 * 1000 // 1 minute
const MAX_REQUESTS = 5

function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const record = rateLimit.get(ip)

  if (!record || now - record.timestamp > RATE_LIMIT_WINDOW) {
    rateLimit.set(ip, { count: 1, timestamp: now })
    return true
  }

  if (record.count >= MAX_REQUESTS) {
    return false
  }

  record.count++
  return true
}

export async function POST(request: Request) {
  try {
    // Get client IP for rate limiting
    const ip = request.headers.get("x-forwarded-for") ?? "unknown"

    // Check rate limit
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429 }
      )
    }

    const data: ContactFormData = await request.json()

    // Validate form data
    const validationError = validateFormData(data)
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 })
    }

    // In a real application, you would:
    // 1. Send an email using a service like Resend, SendGrid, or AWS SES
    // 2. Store the message in a database
    // 3. Send a notification via Slack, Discord, etc.
    
    // For Cloudflare Workers deployment, you could use:
    // - Cloudflare Email Workers (https://developers.cloudflare.com/email-routing/email-workers/)
    // - Cloudflare D1 for storage
    // - External email API (Resend, etc.)

    // Simulating a successful submission
    console.log("Contact form submission:", {
      name: data.name,
      email: data.email,
      subject: data.subject,
      message: data.message.substring(0, 100) + "...",
      timestamp: new Date().toISOString(),
    })

    // Example: Send email with Resend (uncomment and add RESEND_API_KEY env var)
    /*
    const resend = new Resend(process.env.RESEND_API_KEY)
    await resend.emails.send({
      from: "portfolio@yourdomain.com",
      to: "your-email@example.com",
      subject: `Portfolio Contact: ${data.subject}`,
      html: `
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> ${data.name}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Subject:</strong> ${data.subject}</p>
        <p><strong>Message:</strong></p>
        <p>${data.message}</p>
      `,
    })
    */

    return NextResponse.json({
      success: true,
      message: "Message sent successfully! I'll get back to you soon.",
    })
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json(
      { error: "Failed to send message. Please try again." },
      { status: 500 }
    )
  }
}
