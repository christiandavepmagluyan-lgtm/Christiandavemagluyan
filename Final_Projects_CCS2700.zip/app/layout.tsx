import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'Christian Dave P. Magluyan | Full-Stack Developer',
  description: 'Full-Stack Developer crafting modern, high-performance web applications. Specializing in React, Node.js, and cloud infrastructure.',
  keywords: ['Full-Stack Developer', 'React', 'Node.js', 'TypeScript', 'Cloud Architecture', 'Web Development'],
  authors: [{ name: 'Christian Dave P. Magluyan' }],
  openGraph: {
    title: 'Christian Dave P. Magluyan | Full-Stack Developer',
    description: 'Full-Stack Developer crafting modern, high-performance web applications.',
    type: 'website',
  },
  generator: 'Next.js',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-background scroll-smooth">
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
