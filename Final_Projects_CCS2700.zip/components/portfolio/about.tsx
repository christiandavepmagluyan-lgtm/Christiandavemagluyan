import Image from "next/image"
import { Code2, Layers, Rocket } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-24 bg-card">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div className="relative">
            <div className="absolute -inset-4 bg-primary/10 rounded-lg blur-2xl" />
            <div className="relative aspect-[4/5] rounded-lg overflow-hidden bg-muted border border-border">
              <Image
                src="/images/profile.jpg"
                alt="Christian Dave P. Magluyan"
                fill
                className="object-cover object-top"
              />
            </div>
          </div>

          {/* Content */}
          <div>
            <p className="text-primary font-medium tracking-widest uppercase text-sm mb-4">
              About Me
            </p>
            
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              I am a Full-Stack
              <br />
              <span className="text-primary">Developer</span>
            </h2>

            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              With a passion for creating elegant, efficient, and user-friendly web applications. 
              I specialize in building full-stack solutions using modern technologies like React, 
              Node.js, and cloud platforms. My approach combines clean code practices with 
              innovative design thinking to deliver exceptional digital experiences.
            </p>

            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-4 rounded-lg bg-background border border-border">
                <Code2 className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-1">Clean Code</h3>
                <p className="text-muted-foreground text-sm">Maintainable and scalable solutions</p>
              </div>
              
              <div className="p-4 rounded-lg bg-background border border-border">
                <Layers className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-1">Full-Stack</h3>
                <p className="text-muted-foreground text-sm">End-to-end development expertise</p>
              </div>
              
              <div className="p-4 rounded-lg bg-background border border-border">
                <Rocket className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-1">Performance</h3>
                <p className="text-muted-foreground text-sm">Optimized for speed and efficiency</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
