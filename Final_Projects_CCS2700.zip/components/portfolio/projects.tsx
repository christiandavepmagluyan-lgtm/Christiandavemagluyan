"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"

const projects = [
  {
    title: "Order Analytics Dashboard",
    description: "Comprehensive sales analytics dashboard with real-time metrics, interactive charts, and revenue tracking.",
    problem: "Business owners needed a centralized view of sales performance and inventory data.",
    solution: "Built an intuitive dashboard with line charts, pie charts, and key metrics for instant business insights.",
    techStack: ["React", "Chart.js", "Node.js", "PostgreSQL", "REST API"],
    image: "/images/projects/dashboard.png",
    liveUrl: "#",
    githubUrl: "#",
  },
  {
    title: "AI Integration Platform",
    description: "Modern AI-powered application leveraging machine learning for intelligent data processing and automation.",
    problem: "Manual processes were time-consuming and prone to human error.",
    solution: "Integrated AI models to automate workflows and provide intelligent recommendations.",
    techStack: ["Python", "TensorFlow", "React", "FastAPI", "Docker"],
    image: "/images/projects/ai-integration.png",
    liveUrl: "#",
    githubUrl: "#",
  },
  {
    title: "Network Security System",
    description: "Two-factor authentication system with VPN integration, RADIUS server, and Active Directory support.",
    problem: "Organizations needed secure remote access with multi-layer authentication.",
    solution: "Designed comprehensive security architecture with SecureAuth, VPN, and AD integration.",
    techStack: ["WatchGuard", "RADIUS", "Active Directory", "SSL VPN", "SecureAuth"],
    image: "/images/projects/network-security.png",
    liveUrl: null,
    githubUrl: "#",
  },
  {
    title: "E-Commerce Promo System",
    description: "Dynamic promotional banner system for major e-commerce platforms with payment gateway integration.",
    problem: "Marketing teams needed quick deployment of promotional campaigns.",
    solution: "Built flexible promo system with credit card integration and real-time discount calculations.",
    techStack: ["Next.js", "Tailwind CSS", "Payment API", "AWS", "Redis"],
    image: "/images/projects/ecommerce-promo.png",
    liveUrl: "#",
    githubUrl: "#",
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-sm mb-4">
            Portfolio
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            Featured Projects
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            A selection of projects demonstrating expertise in building scalable, 
            secure, and user-friendly applications.
          </p>
        </div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project) => (
            <Card
              key={project.title}
              className="bg-card border-border hover:border-primary/50 transition-all duration-300 group"
            >
              <CardContent className="p-6">
                {/* Project image */}
                <div className="aspect-video bg-muted rounded-lg mb-6 overflow-hidden relative">
                  <Image
                    src={project.image}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                {/* Project info */}
                <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {project.description}
                </p>

                {/* Problem/Solution */}
                <div className="space-y-2 mb-4 text-sm">
                  <div>
                    <span className="font-semibold text-primary">Problem: </span>
                    <span className="text-muted-foreground">{project.problem}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-primary">Solution: </span>
                    <span className="text-muted-foreground">{project.solution}</span>
                  </div>
                </div>

                {/* Tech stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.techStack.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-muted text-muted-foreground text-xs rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3">
                  {project.githubUrl && (
                    <Button variant="outline" size="sm" asChild className="border-border hover:border-primary">
                      <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                        <Github className="w-4 h-4 mr-2" />
                        Code
                      </a>
                    </Button>
                  )}
                  {project.liveUrl && (
                    <Button size="sm" asChild className="bg-primary hover:bg-primary/90">
                      <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Live Demo
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* View all CTA */}
        <div className="text-center mt-12">
          <Button variant="outline" size="lg" className="border-border hover:border-primary" asChild>
            <a href="https://github.com/cdmagluyan" target="_blank" rel="noopener noreferrer">
              <Github className="w-4 h-4 mr-2" />
              View All Projects on GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  )
}
