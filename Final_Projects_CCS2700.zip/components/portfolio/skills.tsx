"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Code2, Database, Cloud, Shield, Wrench, Users } from "lucide-react"

const skillCategories = [
  {
    title: "Frontend",
    icon: Code2,
    skills: ["React", "Next.js", "TypeScript", "Vue.js", "Tailwind CSS", "HTML5/CSS3"],
  },
  {
    title: "Backend",
    icon: Database,
    skills: ["Node.js", "Python", "Go", "PostgreSQL", "MongoDB", "Redis"],
  },
  {
    title: "Cloud & DevOps",
    icon: Cloud,
    skills: ["AWS", "Cloudflare", "Docker", "Kubernetes", "CI/CD", "Terraform"],
  },
  {
    title: "Security",
    icon: Shield,
    skills: ["OAuth2/OIDC", "WebAuthn", "Encryption", "OWASP", "Pen Testing"],
  },
  {
    title: "Tools",
    icon: Wrench,
    skills: ["Git", "GitHub Actions", "VS Code", "Figma", "Jira", "Notion"],
  },
  {
    title: "Soft Skills",
    icon: Users,
    skills: ["Leadership", "Agile/Scrum", "Code Review", "Mentoring", "Documentation"],
  },
]

const experience = [
  {
    title: "Senior Full-Stack Developer",
    company: "TechCorp Inc.",
    period: "2022 - Present",
    description: "Lead developer for e-commerce platform serving 1M+ users. Architected microservices migration reducing costs by 40%.",
  },
  {
    title: "Full-Stack Developer",
    company: "StartupXYZ",
    period: "2020 - 2022",
    description: "Built core features for SaaS analytics product from 0 to 50,000 users. Implemented real-time data pipelines.",
  },
  {
    title: "Junior Developer",
    company: "WebAgency Co.",
    period: "2018 - 2020",
    description: "Developed custom web applications for diverse clients. Focused on responsive design and performance.",
  },
]

export function Skills() {
  return (
    <section id="skills" className="py-24 bg-card">
      <div className="container mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-sm mb-4">
            Expertise
          </p>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            Skills & Experience
          </h2>
        </div>

        {/* Skills grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {skillCategories.map((category) => {
            const Icon = category.icon
            return (
              <Card key={category.title} className="bg-background border-border hover:border-primary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="font-semibold text-foreground">{category.title}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-muted text-muted-foreground text-xs rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Experience timeline */}
        <div className="max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold text-foreground text-center mb-10">
            Work Experience
          </h3>
          
          <div className="space-y-8">
            {experience.map((job, index) => (
              <div key={job.title} className="relative pl-8 border-l-2 border-primary/30">
                <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary" />
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                  <h4 className="font-semibold text-foreground">{job.title}</h4>
                  <span className="text-sm text-muted-foreground">{job.period}</span>
                </div>
                <p className="text-primary text-sm mb-2">{job.company}</p>
                <p className="text-muted-foreground text-sm">{job.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
