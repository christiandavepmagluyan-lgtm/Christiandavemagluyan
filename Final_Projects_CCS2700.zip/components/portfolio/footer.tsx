import { Github, Linkedin, Twitter, Heart } from "lucide-react"

const socialLinks = [
  { href: "https://github.com/cdmagluyan", icon: Github, label: "GitHub" },
  { href: "https://linkedin.com/in/cdmagluyan", icon: Linkedin, label: "LinkedIn" },
  { href: "https://twitter.com/cdmagluyan", icon: Twitter, label: "Twitter" },
]

const footerLinks = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#projects", label: "Projects" },
  { href: "#skills", label: "Skills" },
  { href: "#contact", label: "Contact" },
]

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-border bg-card">
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo and tagline */}
          <div className="text-center md:text-left">
            <a href="#home" className="text-xl font-bold text-foreground hover:text-primary transition-colors">
              <span className="text-primary">CD</span>MAGLUYAN
            </a>
            <p className="mt-2 text-sm text-muted-foreground">
              Full-Stack Developer crafting exceptional digital experiences.
            </p>
          </div>

          {/* Footer navigation */}
          <nav className="flex flex-wrap justify-center gap-6">
            {footerLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Social links */}
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => {
              const Icon = social.icon
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-colors"
                  aria-label={social.label}
                >
                  <Icon className="w-5 h-5" />
                </a>
              )
            })}
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="flex items-center justify-center gap-1 text-sm text-muted-foreground">
            &copy; {currentYear} Christian Dave P. Magluyan. Built with
            <Heart className="w-4 h-4 text-primary" aria-label="love" />
            using Next.js & Tailwind CSS.
          </p>
        </div>
      </div>
    </footer>
  )
}
